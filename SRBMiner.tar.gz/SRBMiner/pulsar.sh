#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

#RPLANT
./SRBMiner-MULTI --disable-gpu --algorithm curvehash --pool stratum-na.rplant.xyz:17030 --wallet PEeZhnDbfbuQR84w87QNgn5fGZizQJeQvU --cpu-threads 3
